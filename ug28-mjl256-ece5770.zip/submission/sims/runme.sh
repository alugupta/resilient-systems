#!/bin/bash

./pinSim.sh

python dbiSim.py
